package org.firstinspires.ftc.teamcode.TeleOp;

import com.acmerobotics.dashboard.config.ConstantProvider;
import com.arcrobotics.ftclib.drivebase.MecanumDrive;
import com.arcrobotics.ftclib.gamepad.GamepadEx;
import com.arcrobotics.ftclib.hardware.motors.Motor;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

@TeleOp
public class Teleop extends OpMode {

    private MecanumDrive drive;
    private GamepadEx driverOp;
    private GamepadEx scoreOP;


    @Override
    public void init() {


        Motor frontLeft = new Motor(hardwareMap, "fl");
        Motor frontRight = new Motor(hardwareMap, "fr");
        Motor backLeft = new Motor(hardwareMap, "bl");
        Motor backRight = new Motor(hardwareMap, "br");
        Motor liftMotor = new Motor(hardwareMap, "lift");
        double liftSpeedMultiplier = 0.6f;


        //elbowServo = hardwareMap.get(Servo.class, "elbow");

        drive = new MecanumDrive(frontLeft, frontRight, backLeft, backRight);
        driverOp = new GamepadEx(gamepad1);
        scoreOP = new GamepadEx(gamepad2);

        double liftPower = scoreOP.getLeftY();
        liftMotor.set(liftPower * liftSpeedMultiplier);
    }
    @Override
    public void loop() {
        //declare all variables

        double driveSpeedMultiplier = -0.5;






        //scoreOP.getGamepadButton(GamepadKeys.Button.DPAD_UP)
                       // .whenPressed(Elbow.Up());
        //scoreOP.getGamepadButton(GamepadKeys.Button.DPAD_DOWN)
                        //.whenPressed(Elbow.Down());


        drive.driveRobotCentric(
                driverOp.getLeftX() * driveSpeedMultiplier,
                driverOp.getLeftY() * driveSpeedMultiplier,
                driverOp.getRightX() * driveSpeedMultiplier
        );




    }

}