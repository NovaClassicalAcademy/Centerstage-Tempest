package org.firstinspires.ftc.teamcode.Subsystems.Arm;

import com.arcrobotics.ftclib.command.SubsystemBase;
import com.arcrobotics.ftclib.hardware.ServoEx;
import com.arcrobotics.ftclib.hardware.motors.Motor;
import com.qualcomm.robotcore.hardware.Servo;

public class Gripper extends SubsystemBase {
    private final ServoEx gripServo1;
    private final ServoEx gripServo2;
    private ServoEx flipServo;
    double GRIPCLOSEDPOSITION = 0;
    double GRIPOPENPOSITION = 1;

    double FLIPUPPOSITION = 1;

    double FLIPDOWNPOSITION = 0;

    public Gripper(ServoEx grip1, ServoEx grip2, ServoEx flip) {
        gripServo1 = grip1;
        gripServo2 = grip2;
        flipServo = flip;
    }
    public void Grip1Close() {
        gripServo1.setPosition(GRIPCLOSEDPOSITION);
    }
    public void Grip2Close() {
        gripServo1.setPosition(GRIPCLOSEDPOSITION);
    }
    public void FlipUp() {
        flipServo.setPosition(FLIPUPPOSITION);
    }
    public void FlipDown() {
        flipServo.setPosition(FLIPDOWNPOSITION);
    }
    public void Grip1Release() {
        gripServo1.setPosition(GRIPOPENPOSITION);
    }
    public void Grip2Release() {
        gripServo1.setPosition(GRIPCLOSEDPOSITION);
    }
}