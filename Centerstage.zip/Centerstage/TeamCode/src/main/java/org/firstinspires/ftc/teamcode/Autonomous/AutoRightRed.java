package org.firstinspires.ftc.teamcode.Autonomous;

public class AutoRightRed {
}
