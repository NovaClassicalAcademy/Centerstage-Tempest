package org.firstinspires.ftc.teamcode.Subsystems.Arm;

import com.arcrobotics.ftclib.command.SubsystemBase;
import com.arcrobotics.ftclib.hardware.motors.Motor;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotor.RunMode;

public class Lift extends SubsystemBase {
    public Motor lift1;
    static float Multiplier = 0.6f;
    public Lift(Motor lift) { lift1 = lift; }
    public void UpWithEncoder(int SCORINGPOSITION, float speed) {
        lift1.set(speed);
        lift1.getCurrentPosition();
        lift1.setTargetPosition(SCORINGPOSITION); }
    public void DownWithEncoder() {
        lift1.set(0.50);
    }
}