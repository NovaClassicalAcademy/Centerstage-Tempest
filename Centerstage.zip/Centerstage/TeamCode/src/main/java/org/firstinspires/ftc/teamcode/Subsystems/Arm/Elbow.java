package org.firstinspires.ftc.teamcode.Subsystems.Arm;

import com.arcrobotics.ftclib.command.Command;
import com.arcrobotics.ftclib.command.SubsystemBase;
import com.qualcomm.robotcore.hardware.Servo;

public class Elbow extends SubsystemBase {
    private static Servo elbowServo;

    public Elbow(Servo elbow) {
        elbowServo = elbow;
    }
    public static Command Down() {
        elbowServo.setPosition(0);
        return null;
    }
    public static Command Up() {
        elbowServo.setPosition(1);
        return null;
    }
}